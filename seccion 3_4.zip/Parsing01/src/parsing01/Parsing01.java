package parsing01;

public class Parsing01 {
    public static void main(String[] args) {
        //Declare and intitialize 3 Strings: shirtPrice, taxRate, and gibberish
        String shirtPrice = "20";
        String taxRate = "1.16";
        String gibberish = "213wqeqw";
        
        
        //Parse shirtPrice and taxRate, and print the total tax
        Double total = Double.parseDouble(shirtPrice) * Double.parseDouble(taxRate);
        
        System.out.print("El total es: " + total);
        //Try to parse taxRate as an int
        Integer tryt = Integer.parseInt(taxRate);
        //Try to parse gibberish as an int
        Integer gibInt = Integer.parseInt(gibberish);
    }
    
}
