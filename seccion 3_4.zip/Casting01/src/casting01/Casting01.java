
package casting01;

public class Casting01 {
    public static void main(String[] args) {
        //Declare and initialize a byte with a value of 128
        //Observe NetBeans' complaint
        byte x = 127; //128 da error porque byte solo acepta un valor máximo de 127
        
        //Declare and initialize a short with a value of 128
        //Create a print statement that casts this short to a byte
        short y = 128;
        byte w = (byte)y;
        System.out.print(w + "\n");
        
        //Declare and initialize a byte with a value of 127
        //Add 1 to this variable and print it
        //Add 1 to this variable again and print it again
        byte n = 127;
        n = (byte) (n + 1);
        System.out.print(n + "\n");
        n = (byte)(n+1);
        System.out.print(n);
    }    
}
